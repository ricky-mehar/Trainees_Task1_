import 'package:firebase_auth/firebase_auth.dart';

import 'package:flutter/material.dart';
import 'package:untitled/signup.dart';
import 'UIofApp.dart';
import 'main.dart';


class Loginpage extends StatefulWidget {
  const Loginpage({super.key});

  @override
  State<Loginpage> createState() => _LoginpageState();
}

class _LoginpageState extends State<Loginpage> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  get value => null;
  login(String email,String password)async{
    if(email==""&&password==""){
      uiofapp.CustomAlertBox(context, "Enter requird fild");
    }else{
      UserCredential ? usercredential;
      try{
        usercredential=await FirebaseAuth.instance.signInWithEmailAndPassword(email: email, password: password).then((value){
          Navigator.push(context, MaterialPageRoute(builder:((context) => MyHomePage(title:"HomePage"))));
        });


      }on FirebaseAuthException catch(ex){
        return uiofapp.CustomAlertBox(context,ex.code.toString());
      }

    }
  }
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
        appBar: AppBar(title: Text("LoginPage"),centerTitle: true),
        body: Column(mainAxisAlignment: MainAxisAlignment.center,
          children: [
            uiofapp.CustomTextField(emailController , "Email", Icons.mail, false),
            uiofapp.CustomTextField(passwordController , "Password", Icons.password, true),
            SizedBox(height:20,),
            uiofapp.CustomButton((){
              login(emailController.text.toString(),passwordController.text.toString());
            },"LOGIN"),
            Row(mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text("Already Have an account",style: TextStyle(fontSize: 20),),
                TextButton(onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>SignUpPage()));
                }, child: Text("Sign up",style:TextStyle(fontSize: 20,fontWeight:FontWeight.w800),)
                )
              ],

            )
          ],
        )
    );
  }
}