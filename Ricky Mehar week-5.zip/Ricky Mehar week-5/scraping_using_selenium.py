


from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from datetime import datetime, timedelta
#import time

import os
import requests
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
#s = Service(r"C:\Users\ricky\OneDrive\Desktop\imp\chromedriver-win64\chromedriver.exe")
#driver = webdriver.Chrome(service = s)#
#driver.get("https://www.sci.gov.in/judgements-judgement-date/")
#time.sleep(4)
# 👇 Setup
service = Service(r"C:\Users\ricky\OneDrive\Desktop\imp\chromedriver-win64\chromedriver.exe")  # <-- Update path as needed
options = Options()
options.add_argument("--start-maximized")

driver = webdriver.Chrome(service=service, options=options)#service

driver.get("https://www.sci.gov.in/judgements-judgement-date/")

input("🔍 Press Enter to start scraping and downloading PDFs...")


pdf_links = driver.find_elements(By.XPATH, "//a[contains(@href, '.pdf')]")

# 📁 Create a download folder
os.makedirs("judgement_pdfs", exist_ok=True)

for link in pdf_links:
    href = link.get_attribute("href")
    if href:
        filename = href.split("/")[-1]
        filepath = os.path.join("judgement_pdfs", filename)
        try:
            print(f"⬇  Downloading {filename}...")
            response = requests.get(href)
            with open(filepath, "wb") as f:
                f.write(response.content)
        except Exception as e:
            print(f"⚠  Failed to download {filename}: {e}")

driver.quit()
print("✅ Done! All PDFs downloaded to the 'judgement_pdfs' folder.")
#driver.quit()